package kalkulatorrsbk.ejb;

import javax.ejb.Stateful;
import javax.ejb.LocalBean;

@Stateful
@LocalBean
public class kalkulatorrsbk implements kalkulatorrsbklocal {

    private double total = 0;
    private int count = 0;
    private double pastTotal = 0;

    @Override
    public double add(double value) {
        pastTotal = total;
        total = total + value;
        count++;
        return total;
    }
    
    
    @Override
    public double min(double value) {
        pastTotal = total;
        total = total - value;
        count++;
        return total;
    }

    
    
    @Override
    public double bagi(double value) {
        pastTotal = total;
        total = total / value;
        count++;
        return total;
    }

    
    
    @Override
    public double kali(double value) {
        pastTotal = total;
        total = total * value;
        count++;
        return total;
    }


    @Override
    public double operasi() {
        return pastTotal;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public double getTotal() {
        return total;
    }
    
    @Override
    public double remove() {
        total = 0;
        return total;
    }
    
    @Override
    public int removeCount() {
        count = 0;
        return count;
    }
}

