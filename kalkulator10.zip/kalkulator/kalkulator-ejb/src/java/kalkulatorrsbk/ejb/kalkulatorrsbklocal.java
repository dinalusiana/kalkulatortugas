package kalkulatorrsbk.ejb;

import javax.ejb.Local;
@Local
public interface kalkulatorrsbklocal {
    public double add(double value);
    public double min(double value);
    public double bagi(double value);
    public double kali(double value);
    public double operasi();
    public int getCount();
    public double getTotal();  
    public double remove(); 
    public int removeCount();
}
